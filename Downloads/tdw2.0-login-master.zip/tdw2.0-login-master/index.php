<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
     <link rel="stylesheet" href="css/main.css">
   <title>Inicio</title>
</head>

<body>
    <header> <!-- encabezado -->
                <aside> <span class="naranja">Mi primer login</span> </aside>
                <nav>
                    <a class="activo" href="index.html">Inicio</a>
                    |
                    <a href=" ">Ingresar</a>
                    |
                    <a href=" ">Nuevo usuario</a>
                </nav>
    </header>

        <div id="contenido">
            <p>Felicidades, bienvenido al mi mundo!</p>
        </div>  <!--termina contenido-->

        <footer>
             <p>Copyleft: TDW2.0</p>
        </footer>

</body>
</html>
